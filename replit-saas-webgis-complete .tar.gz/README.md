# GIS SaaS Platform

A multi-tenant SaaS platform for advanced geospatial data management with dual-mode architecture supporting both standalone and NocoDB integration.

## Features

- **Multi-tenancy**: Isolated customer bases with separate users, permissions, and data
- **Dual Architecture**: Standalone mode with built-in functionality or hybrid mode with NocoDB integration
- **Geospatial Support**: PostGIS-powered spatial data handling with Leaflet.js mapping
- **Advanced Grid View**: Enhanced data table with inline editing, filtering, sorting, and column management
- **Field-level Permissions**: Granular access control for table fields
- **User Management**: Role-based access with admin controls
- **CSV Import**: Comprehensive data import with geometry support
- **API Integration**: RESTful APIs with token-based authentication

## Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Leaflet.js
- **Backend**: Node.js, Express.js, TypeScript
- **Database**: PostgreSQL with PostGIS extension
- **ORM**: Drizzle ORM with Zod validation
- **Authentication**: Session-based with secure token management
- **Build Tools**: Vite, ESBuild

## Quick Start

### Prerequisites

- Node.js 18+ 
- PostgreSQL 15+ with PostGIS extension
- Docker and Docker Compose (optional)

### Environment Setup

1. Copy environment template:
```bash
cp .env.example .env
```

2. Configure your database and application settings in `.env`

### Docker Deployment (Recommended)

```bash
# Set required environment variables
export POSTGRES_PASSWORD=your_secure_password
export SESSION_SECRET=your_session_secret

# Start all services
docker-compose up -d

# Initialize database schema
npm run db:push
```

### Manual Deployment

1. Install dependencies:
```bash
npm install
```

2. Set up PostgreSQL database with PostGIS:
```sql
CREATE EXTENSION postgis;
CREATE EXTENSION postgis_topology;
```

3. Configure environment variables in `.env`

4. Push database schema:
```bash
npm run db:push
```

5. Build and start:
```bash
npm run build
npm start
```

## Production Deployment on Linode

### Server Requirements

- **CPU**: 2+ cores recommended
- **Memory**: 4GB+ RAM
- **Storage**: 50GB+ SSD
- **OS**: Ubuntu 22.04 LTS

### Deployment Steps

1. **Provision Linode Instance**
   - Create a Linode instance with Ubuntu 22.04
   - Set up firewall rules (ports 22, 80, 443)
   - Configure domain DNS to point to Linode IP

2. **Install Dependencies**
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker and Docker Compose
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Node.js (for development)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

3. **Clone and Configure Application**
```bash
# Clone repository
git clone <your-repository-url>
cd gis-saas-platform

# Set environment variables
cp .env.example .env
# Edit .env with your production settings

# Set Docker environment
export POSTGRES_PASSWORD=$(openssl rand -base64 32)
export SESSION_SECRET=$(openssl rand -base64 64)
```

4. **Deploy with Docker**
```bash
# Start services
docker-compose up -d

# Check status
docker-compose ps
docker-compose logs -f app
```

5. **Configure SSL (Optional)**
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot --nginx -d your-domain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

## Customer Data Isolation

Each customer base is isolated with:
- **Separate database schemas** for data segregation
- **File-based storage** in customer-specific directories under `/var/lib/app/data/`
- **Upload isolation** in `/var/lib/app/uploads/{baseId}/`
- **Session isolation** with base-specific tokens

## Configuration

### Deployment Modes

1. **Standalone Mode**: Full self-contained functionality
   ```env
   DEPLOYMENT_MODE=standalone
   ```

2. **NocoDB Mode**: Integration with existing NocoDB instance
   ```env
   DEPLOYMENT_MODE=nocodb
   NOCODB_BASE_URL=https://your-nocodb.com
   NOCODB_API_TOKEN=your_api_token
   ```

3. **Hybrid Mode**: Seamless switching between modes
   ```env
   DEPLOYMENT_MODE=hybrid
   ```

### Database Configuration

PostgreSQL with PostGIS:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/database
PGHOST=localhost
PGPORT=5432
PGUSER=gis_user
PGPASSWORD=secure_password
PGDATABASE=gis_saas
```

## API Documentation

### Authentication

All API endpoints require authentication via session tokens or API keys.

### Base Management

- `GET /api/super-admin/bases` - List all bases
- `POST /api/super-admin/bases` - Create new base
- `GET /api/base/tables` - List tables in current base
- `POST /api/base/tables` - Create new table

### Data Operations

- `GET /api/base/tables/{id}/records` - Get table records
- `POST /api/base/tables/{id}/records` - Create record
- `PATCH /api/base/tables/{id}/records/{recordId}` - Update record
- `DELETE /api/base/tables/{id}/records/{recordId}` - Delete record

## Security

- **HTTPS Only**: Force SSL in production
- **Rate Limiting**: API endpoint protection
- **Input Validation**: Zod schema validation
- **SQL Injection Protection**: Parameterized queries
- **XSS Protection**: Content Security Policy headers
- **Session Security**: Secure cookie settings

## Monitoring

Health check endpoint: `GET /health`

Monitor with:
```bash
# Check application health
curl -f http://localhost:5000/health

# Monitor logs
docker-compose logs -f app

# Database monitoring
docker-compose exec postgres psql -U gis_user -d gis_saas -c "SELECT count(*) FROM bases;"
```

## Backup Strategy

### Database Backups
```bash
# Create backup
docker-compose exec postgres pg_dump -U gis_user gis_saas > backup_$(date +%Y%m%d_%H%M%S).sql

# Restore backup
docker-compose exec -T postgres psql -U gis_user gis_saas < backup_file.sql
```

### File System Backups
```bash
# Backup customer data
tar -czf data_backup_$(date +%Y%m%d).tar.gz /var/lib/app/data/
tar -czf uploads_backup_$(date +%Y%m%d).tar.gz /var/lib/app/uploads/
```

## Support

For deployment assistance or issues:
1. Check application logs: `docker-compose logs app`
2. Verify database connectivity: `docker-compose exec postgres psql -U gis_user gis_saas`
3. Review environment configuration in `.env`

## License

MIT License - see LICENSE file for details.