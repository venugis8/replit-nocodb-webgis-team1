// System Mode Management
export type SystemMode = 'standalone' | 'nocodb';

export interface BaseConfig {
  id: number;
  name: string;
  subdomain: string;
  systemMode: SystemMode;
  nocodbBaseId?: string | null;
  nocodbUrl?: string | null;
  nocodbApiKey?: string | null;
  sitesTableId?: string | null;
}

export function getSystemModeLabel(mode: SystemMode): string {
  switch (mode) {
    case 'standalone':
      return 'Standalone System';
    case 'nocodb':
      return 'NocoDB Integration';
    default:
      return 'Unknown Mode';
  }
}

export function getSystemModeDescription(mode: SystemMode): string {
  switch (mode) {
    case 'standalone':
      return 'Full standalone system with built-in table and permission management';
    case 'nocodb':
      return 'Hybrid mode with NocoDB backend for advanced data management';
    default:
      return '';
  }
}

export function isNocoDbConfigured(config: BaseConfig): boolean {
  if (config.systemMode !== 'nocodb') return true;
  
  return !!(
    config.nocodbBaseId &&
    config.nocodbUrl &&
    config.nocodbApiKey
  );
}

export function getSystemModeStatus(config: BaseConfig): {
  status: 'ready' | 'configuration_required' | 'partial';
  message: string;
} {
  if (config.systemMode === 'standalone') {
    return {
      status: 'ready',
      message: 'Standalone system ready'
    };
  }
  
  if (config.systemMode === 'nocodb') {
    if (isNocoDbConfigured(config)) {
      return {
        status: 'ready',
        message: 'NocoDB integration configured'
      };
    } else {
      return {
        status: 'configuration_required',
        message: 'NocoDB configuration required'
      };
    }
  }
  
  return {
    status: 'partial',
    message: 'Unknown configuration'
  };
}