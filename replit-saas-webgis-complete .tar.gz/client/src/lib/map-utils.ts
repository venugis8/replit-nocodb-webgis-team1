declare global {
  interface Window {
    L: any;
  }
}

export function createMap(container: HTMLElement) {
  if (!window.L) {
    throw new Error('Leaflet not loaded');
  }

  const map = window.L.map(container).setView([37.7749, -122.4194], 10);

  window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap contributors'
  }).addTo(map);

  return map;
}

export function createMarker(coordinates: [number, number], color: string) {
  if (!window.L) {
    throw new Error('Leaflet not loaded');
  }

  return window.L.circleMarker(coordinates, {
    color: color,
    fillColor: color,
    fillOpacity: 0.7,
    radius: 8,
    weight: 2
  });
}

export function getMarkerColor(category: string): string {
  switch (category.toLowerCase()) {
    case 'office':
      return '#3B82F6'; // blue
    case 'warehouse':
      return '#10B981'; // green
    case 'retail':
      return '#8B5CF6'; // purple
    default:
      return '#6B7280'; // gray
  }
}

export function formatPopupContent(location: any): string {
  return `
    <div class="p-3 min-w-48">
      <h3 class="font-semibold text-gray-900 mb-2">${location.name}</h3>
      <p class="text-sm text-gray-600 mb-1">${location.address}</p>
      <p class="text-xs text-gray-500 mb-2">Category: ${location.category}</p>
      <div class="flex items-center space-x-1 mb-3">
        <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full ${
          location.status?.toLowerCase() === 'active' 
            ? 'bg-emerald-100 text-emerald-800' 
            : 'bg-amber-100 text-amber-800'
        }">
          ${location.status}
        </span>
      </div>
      <div class="flex space-x-2">
        <button class="px-2 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700">
          Edit
        </button>
        <button class="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded hover:bg-gray-200">
          View Details
        </button>
      </div>
    </div>
  `;
}
