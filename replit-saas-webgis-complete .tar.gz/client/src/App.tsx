import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import SuperAdminPage from "@/pages/super-admin";
import BaseWorkspacePage from "@/pages/base-workspace";
import LoginPage from "@/pages/login";
import MapFullscreenPage from "@/pages/map-fullscreen";
import MasterAdminPage from "@/pages/master-admin";
import LogsPage from "@/pages/logs";
import AdminSetupPage from "@/pages/admin-setup";
import TestMagicLinkPage from "@/pages/test-magic-link";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={SuperAdminPage} />
      <Route path="/super-admin" component={SuperAdminPage} />
      <Route path="/login/:subdomain?" component={LoginPage} />
      <Route path="/base/:subdomain" component={BaseWorkspacePage} />
      <Route path="/base/:subdomain/master" component={MasterAdminPage} />
      <Route path="/base/:subdomain/logs" component={LogsPage} />
      <Route path="/map/:subdomain" component={MapFullscreenPage} />
      <Route path="/admin-setup/:token" component={AdminSetupPage} />
      <Route path="/test-magic-link" component={TestMagicLinkPage} />
      {/* Direct subdomain access routes */}
      <Route path="/:subdomain" component={BaseWorkspacePage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
