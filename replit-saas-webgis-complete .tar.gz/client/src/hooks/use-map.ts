import { useCallback } from "react";
import { createMap, createMarker, getMarkerColor, formatPopupContent } from "@/lib/map-utils";

declare global {
  interface Window {
    L: any;
  }
}

export function useMap() {
  const initializeMap = useCallback((container: HTMLElement) => {
    if (!window.L) {
      console.error('Leaflet not loaded');
      return null;
    }

    return createMap(container);
  }, []);

  const addMarkers = useCallback((map: any, data: any[]) => {
    if (!map || !data.length) return;

    data.forEach(record => {
      let lat, lng;
      
      // First check the designated geometry column if available
      if (record._geometryColumn && record[record._geometryColumn]) {
        const value = record[record._geometryColumn];
        if (typeof value === 'string' && value.includes(',')) {
          const coords = value.split(',').map(c => parseFloat(c.trim()));
          if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
            lat = coords[0];
            lng = coords[1];
          }
        }
      }

      // Fallback: Look for coordinate data in any field with coordinate-like values
      if (!lat || !lng) {
        Object.keys(record).forEach(key => {
          if (key.startsWith('_')) return; // Skip metadata fields
          const value = record[key];
          if (typeof value === 'string' && value.includes(',')) {
            const coords = value.split(',').map(c => parseFloat(c.trim()));
            if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
              lat = coords[0];
              lng = coords[1];
            }
          }
        });
      }

      if (lat && lng && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
        const color = getMarkerColor(record._tableDisplayName || record.category || record.status || 'default');
        const marker = createMarker([lat, lng], color);
        
        // Create popup with table info and record data
        const tableInfo = record._tableDisplayName ? `<strong>Table:</strong> ${record._tableDisplayName}<br/>` : '';
        const recordData = Object.keys(record)
          .filter(key => !key.startsWith('_') && key !== 'id')
          .map(key => `<strong>${key}:</strong> ${record[key] || 'N/A'}`)
          .join('<br/>');
        const popupContent = `<div>${tableInfo}${recordData}</div>`;
        
        marker.bindPopup(popupContent);
        marker.addTo(map);
      }
    });
  }, []);

  const fitToBounds = useCallback((map: any, data: any[]) => {
    if (!map || !data.length) return;

    const validCoords: [number, number][] = [];

    data.forEach(record => {
      let lat, lng;
      
      // Same coordinate detection logic as addMarkers
      Object.keys(record).forEach(key => {
        const value = record[key];
        if (typeof value === 'string' && value.includes(',')) {
          const coords = value.split(',').map(c => parseFloat(c.trim()));
          if (coords.length === 2 && !isNaN(coords[0]) && !isNaN(coords[1])) {
            lat = coords[0];
            lng = coords[1];
          }
        }
      });

      if (!lat || !lng) {
        const latFields = ['lat', 'latitude', 'y'];
        const lngFields = ['lng', 'longitude', 'lon', 'x'];
        
        for (const field of latFields) {
          if (record[field] && !isNaN(parseFloat(record[field]))) {
            lat = parseFloat(record[field]);
            break;
          }
        }
        
        for (const field of lngFields) {
          if (record[field] && !isNaN(parseFloat(record[field]))) {
            lng = parseFloat(record[field]);
            break;
          }
        }
      }

      if (lat && lng && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
        validCoords.push([lat, lng]);
      }
    });

    if (validCoords.length > 0) {
      const group = window.L.featureGroup(
        validCoords.map(coords => window.L.marker(coords))
      );
      map.fitBounds(group.getBounds().pad(0.1));
    }
  }, []);

  return {
    initializeMap,
    addMarkers,
    fitToBounds,
  };
}
