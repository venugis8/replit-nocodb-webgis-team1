import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { getCurrentUser, getCurrentBase, isAuthenticated } from "@/lib/auth";

interface BaseConfig {
  id: number;
  name: string;
  subdomain: string;
  nocodbBaseId?: string;
  nocodbUrl?: string;
  nocodbApiKey?: string;
  nocodbAdminEmail?: string;
  nocodbAdminPassword?: string;
  sitesTableId?: string;
}

export default function MasterAdminPage() {
  const { subdomain } = useParams();
  const [, setLocation] = useLocation();
  const [iframeLoaded, setIframeLoaded] = useState(false);

  const currentUser = getCurrentUser();
  const currentBase = getCurrentBase();

  const { data: baseConfig, isLoading } = useQuery<BaseConfig>({
    queryKey: ["/api/base/config"],
    enabled: isAuthenticated(),
  });

  useEffect(() => {
    if (!isAuthenticated() || !currentBase || currentBase.subdomain !== subdomain) {
      setLocation(`/login/${subdomain}`);
    }
  }, [subdomain, setLocation, currentBase]);

  const openNocodbDashboard = () => {
    if (!baseConfig) return;
    
    // Simple approach: open NocoDB login page in new tab
    // The user will need to manually enter credentials for now
    const dashboardUrl = `${baseConfig.nocodbUrl}/dashboard/${baseConfig.nocodbBaseId}`;
    window.open(dashboardUrl, '_blank');
    
    // Show a helpful message with credentials
    const message = `
NocoDB Dashboard opened in new tab.
Please use these admin credentials to log in:

Email: ${baseConfig.nocodbAdminEmail}
Password: ${baseConfig.nocodbAdminPassword}
    `;
    
    alert(message);
  };

  // Check if user has admin privileges
  if (currentUser?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-lock text-red-600 text-xl"></i>
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Access Denied</h2>
            <p className="text-gray-600 mb-4">
              Only administrators can access the Master Admin interface.
            </p>
            <Button onClick={() => setLocation(`/base/${subdomain}`)}>
              Return to Workspace
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Check if NocoDB is configured for this base
  if (!isLoading && (!baseConfig?.nocodbBaseId || !baseConfig?.nocodbUrl || !baseConfig?.nocodbAdminEmail || !baseConfig?.nocodbAdminPassword)) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-lg">
          <CardContent className="p-6 text-center">
            <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-cog text-yellow-600 text-xl"></i>
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">NocoDB Not Configured</h2>
            <p className="text-gray-600 mb-4">
              This base hasn't been configured with NocoDB integration yet or admin credentials are missing. 
              Please contact your super administrator to set up the complete NocoDB connection.
            </p>
            <Button onClick={() => setLocation(`/base/${subdomain}`)}>
              Return to Workspace
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Skeleton className="h-8 w-8 rounded" />
              <Skeleton className="h-6 w-48" />
            </div>
            <Skeleton className="h-9 w-24" />
          </div>
        </div>
        <div className="p-6">
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
              <i className="fas fa-database text-white text-sm"></i>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-gray-900">Master Admin Dashboard</h1>
              <p className="text-sm text-gray-500">{baseConfig?.name}</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              Connected to NocoDB
            </Badge>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setLocation(`/base/${subdomain}`)}
            >
              Return to Workspace
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <i className="fas fa-external-link-alt text-blue-600"></i>
              <span>NocoDB Administration</span>
            </CardTitle>
            <p className="text-sm text-gray-600">
              You are automatically logged into NocoDB with admin privileges. 
              Use this interface to manage your database structure, relationships, and advanced settings.
            </p>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-external-link-alt text-blue-600 text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Access NocoDB Dashboard</h3>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                Click the button below to open the NocoDB dashboard in a new tab. 
                You'll be automatically logged in with admin privileges.
              </p>
              <Button 
                onClick={openNocodbDashboard}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3"
                size="lg"
              >
                <i className="fas fa-external-link-alt mr-2"></i>
                Open NocoDB Dashboard
              </Button>
              <p className="text-xs text-gray-500 mt-4">
                Base ID: {baseConfig?.nocodbBaseId}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}