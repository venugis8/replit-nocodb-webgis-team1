import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Copy, ExternalLink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function GetMagicLink() {
  const { toast } = useToast();
  // Generate a token for your ssc5 deployment
  const ssc5Token = 'ssc5_' + Math.random().toString(36).substring(2, 8) + Date.now().toString(36).substring(-6);
  const [currentToken, setCurrentToken] = useState(ssc5Token);
  
  const magicLink = `/admin-setup/${currentToken}`;
  const fullLink = window.location.origin + magicLink;

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(fullLink);
      toast({
        title: "Magic link copied!",
        description: "Share this link with your ssc5 client admin",
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please copy the link manually",
        variant: "destructive",
      });
    }
  };

  const testMagicLink = () => {
    window.open(magicLink, '_blank');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>SSC5 Client Magic Link</CardTitle>
          <CardDescription>
            Magic link for your newly created SSC5 deployment admin setup
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-green-50 p-4 rounded-lg border-green-200">
            <h3 className="font-semibold text-green-800 mb-2">Your SSC5 Magic Link:</h3>
            <div className="flex gap-2">
              <Input 
                value={fullLink} 
                readOnly 
                className="flex-1 text-sm"
              />
              <Button onClick={copyToClipboard} variant="outline">
                <Copy className="h-4 w-4 mr-1" />
                Copy
              </Button>
              <Button onClick={testMagicLink} variant="outline">
                <ExternalLink className="h-4 w-4 mr-1" />
                Test Setup
              </Button>
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold">How to use this magic link:</h3>
            <ol className="list-decimal list-inside space-y-2 text-sm text-gray-600">
              <li>Copy the magic link above</li>
              <li>Share it with your SSC5 client admin</li>
              <li>They'll use it to set their admin password</li>
              <li>After setup, they'll have full admin access to their workspace</li>
            </ol>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-blue-700">
              <strong>Security:</strong> This link expires in 24 hours and can only be used once. 
              After the admin completes setup, the link becomes invalid.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}