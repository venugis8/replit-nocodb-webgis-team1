import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import SystemModeSwitcher from "@/components/system-mode-switcher";
import DeploymentSelectorModal from "@/components/deployment-selector-modal";
import MagicLinkBanner from "@/components/magic-link-banner";
import { getSystemModeLabel, getSystemModeStatus } from "@/lib/system-mode";
import { Skeleton } from "@/components/ui/skeleton";
import { Copy, ExternalLink } from "lucide-react";

interface Base {
  id: number;
  name: string;
  subdomain: string;
  customDomain?: string;
  status: string;
  userCount: number;
  tableCount: number;
  createdAt: string;
  magicLink?: string;
  adminEmail?: string;
}

export default function SuperAdminPage() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isDeploymentModalOpen, setIsDeploymentModalOpen] = useState(false);
  const [lastCreatedBase, setLastCreatedBase] = useState<any>(null);
  const [newBaseName, setNewBaseName] = useState("");
  const [newBaseSubdomain, setNewBaseSubdomain] = useState("");
  // NocoDB Configuration Fields
  const [nocodbBaseId, setNocodbBaseId] = useState("");
  const [nocodbUrl, setNocodbUrl] = useState("");
  const [nocodbApiKey, setNocodbApiKey] = useState("");
  const [sitesTableId, setSitesTableId] = useState("");
  const { toast } = useToast();

  const { data: bases, isLoading } = useQuery<Base[]>({
    queryKey: ["/api/super-admin/bases"],
  });

  const createBaseMutation = useMutation({
    mutationFn: async (baseData: { 
      name: string; 
      subdomain: string; 
      dbPath: string;
      nocodbBaseId?: string;
      nocodbUrl?: string;
      nocodbApiKey?: string;
      sitesTableId?: string;
    }) => {
      const response = await apiRequest("POST", "/api/super-admin/bases", baseData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/super-admin/bases"] });
      setIsCreateModalOpen(false);
      setNewBaseName("");
      setNewBaseSubdomain("");
      setNocodbBaseId("");
      setNocodbUrl("");
      setNocodbApiKey("");
      setSitesTableId("");
      toast({
        title: "Base Created",
        description: "New client base has been created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create base. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteBaseMutation = useMutation({
    mutationFn: async (baseId: number) => {
      await apiRequest("DELETE", `/api/super-admin/bases/${baseId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/super-admin/bases"] });
      toast({
        title: "Base Deleted",
        description: "Base has been deleted successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete base. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateBase = () => {
    if (!newBaseName || !newBaseSubdomain) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    createBaseMutation.mutate({
      name: newBaseName,
      subdomain: newBaseSubdomain,
      dbPath: `/data/${newBaseSubdomain}.db`,
      nocodbBaseId: nocodbBaseId || undefined,
      nocodbUrl: nocodbUrl || undefined,
      nocodbApiKey: nocodbApiKey || undefined,
      sitesTableId: sitesTableId || undefined,
    });
  };

  const stats = bases ? {
    totalBases: bases.length,
    activeUsers: bases.reduce((sum, base) => sum + base.userCount, 0),
    totalTables: bases.reduce((sum, base) => sum + base.tableCount, 0),
  } : null;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-database text-white text-sm"></i>
              </div>
              <h1 className="text-xl font-semibold text-gray-900">NocoBase</h1>
            </div>
            <Badge variant="secondary" className="bg-amber-100 text-amber-800">
              Super Admin
            </Badge>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <i className="fas fa-bell mr-2"></i>
              Notifications
            </Button>
            <div className="flex items-center space-x-3">
              <img 
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&w=32&h=32&fit=crop&crop=face" 
                alt="Admin avatar" 
                className="w-8 h-8 rounded-full"
              />
              <span className="text-sm font-medium text-gray-700">Admin User</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Magic Links for Recent Deployments */}
        <div className="mb-6 space-y-3">
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-green-800">✅ Magic Link for SSC5 Admin</p>
                  <p className="text-xs text-green-600">Copy and share this link to complete admin setup</p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    navigator.clipboard.writeText(`${window.location.origin}/admin-setup/ssc5demo123`);
                    toast({ title: "Copied!", description: "SSC5 magic link copied to clipboard" });
                  }}
                >
                  <Copy className="h-4 w-4 mr-1" />
                  Copy SSC5 Link
                </Button>
              </div>
            </CardContent>
          </Card>
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-800">✅ Magic Link for SSC6 Admin</p>
                  <p className="text-xs text-blue-600">Copy and share this link to complete admin setup</p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    navigator.clipboard.writeText(`${window.location.origin}/admin-setup/ssc6demo123`);
                    toast({ title: "Copied!", description: "SSC6 magic link copied to clipboard" });
                  }}
                >
                  <Copy className="h-4 w-4 mr-1" />
                  Copy SSC6 Link
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Bases</p>
                  {isLoading ? (
                    <Skeleton className="h-8 w-16 mt-2" />
                  ) : (
                    <p className="text-3xl font-bold text-gray-900">{stats?.totalBases || 0}</p>
                  )}
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-cube text-primary"></i>
                </div>
              </div>
              <p className="text-sm text-emerald-600 mt-2">+12% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Users</p>
                  {isLoading ? (
                    <Skeleton className="h-8 w-20 mt-2" />
                  ) : (
                    <p className="text-3xl font-bold text-gray-900">{stats?.activeUsers || 0}</p>
                  )}
                </div>
                <div className="w-12 h-12 bg-emerald-50 rounded-lg flex items-center justify-center">
                  <i className="fas fa-users text-emerald-600"></i>
                </div>
              </div>
              <p className="text-sm text-emerald-600 mt-2">+8% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Tables</p>
                  {isLoading ? (
                    <Skeleton className="h-8 w-16 mt-2" />
                  ) : (
                    <p className="text-3xl font-bold text-gray-900">{stats?.totalTables || 0}</p>
                  )}
                </div>
                <div className="w-12 h-12 bg-amber-50 rounded-lg flex items-center justify-center">
                  <i className="fas fa-table text-amber-600"></i>
                </div>
              </div>
              <p className="text-sm text-emerald-600 mt-2">+5% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">API Requests</p>
                  <p className="text-3xl font-bold text-gray-900">892K</p>
                </div>
                <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                  <i className="fas fa-chart-line text-purple-600"></i>
                </div>
              </div>
              <p className="text-sm text-emerald-600 mt-2">+23% from last month</p>
            </CardContent>
          </Card>
        </div>

        {/* Base Management */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Customer Bases</CardTitle>
              <div className="flex items-center space-x-3">
                <Button 
                  onClick={() => setIsDeploymentModalOpen(true)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <i className="fas fa-rocket mr-2"></i>
                  Deploy System
                </Button>
                <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <i className="fas fa-plus mr-2"></i>
                      Quick Create
                    </Button>
                  </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Base</DialogTitle>
                    <DialogDescription>
                      Create a new isolated database environment for a client.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="baseName">Base Name</Label>
                      <Input
                        id="baseName"
                        value={newBaseName}
                        onChange={(e) => setNewBaseName(e.target.value)}
                        placeholder="e.g., Acme Corp Base"
                      />
                    </div>
                    <div>
                      <Label htmlFor="subdomain">Subdomain</Label>
                      <Input
                        id="subdomain"
                        value={newBaseSubdomain}
                        onChange={(e) => setNewBaseSubdomain(e.target.value)}
                        placeholder="e.g., acme-corp"
                      />
                      <p className="text-sm text-gray-500 mt-1">
                        Will be accessible at: {newBaseSubdomain}.nocobase.com
                      </p>
                    </div>
                    
                    {/* NocoDB Integration Section */}
                    <div className="border-t pt-4 mt-4">
                      <h4 className="font-medium text-gray-900 mb-3">NocoDB Integration (Optional)</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="nocodbBaseId">NocoDB Base ID</Label>
                          <Input
                            id="nocodbBaseId"
                            value={nocodbBaseId}
                            onChange={(e) => setNocodbBaseId(e.target.value)}
                            placeholder="p123abc..."
                          />
                        </div>
                        <div>
                          <Label htmlFor="nocodbUrl">NocoDB URL</Label>
                          <Input
                            id="nocodbUrl"
                            value={nocodbUrl}
                            onChange={(e) => setNocodbUrl(e.target.value)}
                            placeholder="https://app.nocodb.com"
                          />
                        </div>
                        <div>
                          <Label htmlFor="nocodbApiKey">API Key</Label>
                          <Input
                            id="nocodbApiKey"
                            type="password"
                            value={nocodbApiKey}
                            onChange={(e) => setNocodbApiKey(e.target.value)}
                            placeholder="Enter API key..."
                          />
                        </div>
                        <div>
                          <Label htmlFor="sitesTableId">Sites Table ID</Label>
                          <Input
                            id="sitesTableId"
                            value={sitesTableId}
                            onChange={(e) => setSitesTableId(e.target.value)}
                            placeholder="m123def..."
                          />
                        </div>
                      </div>
                      <p className="text-sm text-gray-500 mt-2">
                        Configure NocoDB integration for enhanced data management features.
                      </p>
                    </div>

                    <div className="flex justify-end space-x-2">
                      <Button 
                        variant="outline" 
                        onClick={() => setIsCreateModalOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button 
                        onClick={handleCreateBase} 
                        disabled={createBaseMutation.isPending}
                      >
                        {createBaseMutation.isPending ? "Creating..." : "Create Base"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4">
                    <Skeleton className="h-12 w-12 rounded-lg" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-40" />
                      <Skeleton className="h-3 w-32" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Base Name</TableHead>
                    <TableHead>Subdomain</TableHead>
                    <TableHead>Users</TableHead>
                    <TableHead>Tables</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bases?.map((base) => (
                    <TableRow key={base.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                            <i className="fas fa-database text-primary text-xs"></i>
                          </div>
                          <span className="font-medium">{base.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                          {base.subdomain}.nocobase.com
                        </code>
                      </TableCell>
                      <TableCell>{base.userCount}</TableCell>
                      <TableCell>{base.tableCount}</TableCell>
                      <TableCell>
                        <Badge 
                          variant={base.status === 'active' ? 'default' : 'secondary'}
                          className={base.status === 'active' ? 'bg-emerald-100 text-emerald-800' : ''}
                        >
                          {base.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => window.open(`/login/${base.subdomain}`, '_blank')}
                          >
                            Access Base
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-red-600 hover:text-red-700"
                            onClick={() => deleteBaseMutation.mutate(base.id)}
                            disabled={deleteBaseMutation.isPending}
                          >
                            Delete
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Deployment Selector Modal */}
        <DeploymentSelectorModal
          isOpen={isDeploymentModalOpen}
          onClose={() => setIsDeploymentModalOpen(false)}
        />
      </div>
    </div>
  );
}
