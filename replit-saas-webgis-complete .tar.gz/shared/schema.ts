import { pgTable, text, serial, integer, boolean, timestamp, jsonb, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Super admin users table
export const superAdmins = pgTable("super_admins", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Client bases table - each base is a tenant
export const bases = pgTable("bases", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  subdomain: text("subdomain").notNull().unique(),
  customDomain: text("custom_domain"),
  dbPath: text("db_path").notNull(), // SQLite database path for this base
  status: text("status").notNull().default("active"), // active, maintenance, suspended
  settings: jsonb("settings").default({}),
  // System Mode Configuration
  systemMode: text("system_mode").notNull().default("standalone"), // "standalone" or "nocodb"
  deploymentType: text("deployment_type").notNull().default("basic"), // "basic", "professional", "enterprise", "custom"
  // NocoDB Integration Configuration (only used when systemMode = "nocodb")
  nocodbBaseId: text("nocodb_base_id"),
  nocodbUrl: text("nocodb_url"),
  nocodbApiKey: text("nocodb_api_key"),
  nocodbAdminEmail: text("nocodb_admin_email"),
  nocodbAdminPassword: text("nocodb_admin_password"),
  sitesTableId: text("sites_table_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Magic links for client admin onboarding
export const magicLinks = pgTable("magic_links", {
  id: serial("id").primaryKey(),
  baseId: integer("base_id").references(() => bases.id).notNull(),
  adminEmail: text("admin_email").notNull(),
  token: text("token").notNull().unique(),
  isUsed: boolean("is_used").default(false),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Base users table - users within each base
export const baseUsers = pgTable("base_users", {
  id: serial("id").primaryKey(),
  baseId: integer("base_id").references(() => bases.id).notNull(),
  username: text("username").notNull(),
  email: text("email").notNull(),
  password: text("password").notNull(),
  name: text("name"),
  role: text("role").notNull().default("viewer"), // admin, editor, viewer
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  uniqueEmailPerBase: unique().on(table.baseId, table.email),
  uniqueUsernamePerBase: unique().on(table.baseId, table.username),
}));

// Tables within each base - metadata about SQLite tables
export const baseTables = pgTable("base_tables", {
  id: serial("id").primaryKey(),
  baseId: integer("base_id").references(() => bases.id).notNull(),
  tableName: text("table_name").notNull(),
  displayName: text("display_name").notNull(),
  hasGeometry: boolean("has_geometry").default(false),
  geometryColumn: text("geometry_column"),
  schema: jsonb("schema").notNull(), // Table schema definition
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  uniqueTablePerBase: unique().on(table.baseId, table.tableName),
}));

// Field-level permissions for users
export const fieldPermissions = pgTable("field_permissions", {
  id: serial("id").primaryKey(),
  baseId: integer("base_id").references(() => bases.id).notNull(),
  userId: integer("user_id").references(() => baseUsers.id).notNull(),
  tableId: integer("table_id").references(() => baseTables.id).notNull(),
  fieldName: text("field_name").notNull(),
  permission: text("permission").notNull(), // view, edit, hidden
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  uniqueFieldPermission: unique().on(table.baseId, table.userId, table.tableId, table.fieldName),
}));

// API tokens for each base
export const apiTokens = pgTable("api_tokens", {
  id: serial("id").primaryKey(),
  baseId: integer("base_id").references(() => bases.id).notNull(),
  name: text("name").notNull(),
  token: text("token").notNull().unique(),
  permissions: jsonb("permissions").default({}),
  isActive: boolean("is_active").default(true),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// User sessions for base-specific authentication
export const userSessions = pgTable("user_sessions", {
  id: serial("id").primaryKey(),
  baseId: integer("base_id").references(() => bases.id).notNull(),
  userId: integer("user_id").references(() => baseUsers.id).notNull(),
  sessionToken: text("session_token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const editLogs = pgTable("edit_logs", {
  id: serial("id").primaryKey(),
  baseId: integer("base_id").references(() => bases.id, { onDelete: "cascade" }).notNull(),
  userId: integer("user_id").references(() => baseUsers.id, { onDelete: "cascade" }).notNull(),
  tableId: integer("table_id").references(() => baseTables.id, { onDelete: "cascade" }).notNull(),
  recordId: integer("record_id").notNull(),
  fieldName: text("field_name").notNull(),
  oldValue: text("old_value"),
  newValue: text("new_value"),
  action: text("action").notNull(), // 'create', 'update', 'delete'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Schema validation
export const insertSuperAdminSchema = createInsertSchema(superAdmins).omit({
  id: true,
  createdAt: true,
});

export const insertBaseSchema = createInsertSchema(bases).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBaseUserSchema = createInsertSchema(baseUsers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBaseTableSchema = createInsertSchema(baseTables).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFieldPermissionSchema = createInsertSchema(fieldPermissions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertApiTokenSchema = createInsertSchema(apiTokens).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEditLogSchema = createInsertSchema(editLogs).omit({
  id: true,
  createdAt: true,
});

export const insertMagicLinkSchema = createInsertSchema(magicLinks).omit({
  id: true,
  createdAt: true,
});

// Types
export type SuperAdmin = typeof superAdmins.$inferSelect;
export type InsertSuperAdmin = z.infer<typeof insertSuperAdminSchema>;

export type Base = typeof bases.$inferSelect;
export type InsertBase = z.infer<typeof insertBaseSchema>;

export type BaseUser = typeof baseUsers.$inferSelect;
export type InsertBaseUser = z.infer<typeof insertBaseUserSchema>;

export type BaseTable = typeof baseTables.$inferSelect;
export type InsertBaseTable = z.infer<typeof insertBaseTableSchema>;

export type FieldPermission = typeof fieldPermissions.$inferSelect;
export type InsertFieldPermission = z.infer<typeof insertFieldPermissionSchema>;

export type ApiToken = typeof apiTokens.$inferSelect;
export type InsertApiToken = z.infer<typeof insertApiTokenSchema>;

export type UserSession = typeof userSessions.$inferSelect;

export type EditLog = typeof editLogs.$inferSelect;
export type InsertEditLog = z.infer<typeof insertEditLogSchema>;

export type MagicLink = typeof magicLinks.$inferSelect;
export type InsertMagicLink = z.infer<typeof insertMagicLinkSchema>;
