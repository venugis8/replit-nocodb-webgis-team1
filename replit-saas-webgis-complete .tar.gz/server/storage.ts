import { 
  superAdmins, 
  bases, 
  baseUsers, 
  baseTables, 
  fieldPermissions, 
  apiTokens,
  userSessions,
  editLogs,
  magicLinks,
  type SuperAdmin, 
  type InsertSuperAdmin,
  type Base,
  type InsertBase,
  type BaseUser,
  type InsertBaseUser,
  type BaseTable,
  type InsertBaseTable,
  type FieldPermission,
  type InsertFieldPermission,
  type ApiToken,
  type InsertApiToken,
  type UserSession,
  type EditLog,
  type InsertEditLog,
  type MagicLink,
  type InsertMagicLink
} from "@shared/schema";

export interface IStorage {
  // Super Admin operations
  getSuperAdmin(id: number): Promise<SuperAdmin | undefined>;
  getSuperAdminByEmail(email: string): Promise<SuperAdmin | undefined>;
  createSuperAdmin(admin: InsertSuperAdmin): Promise<SuperAdmin>;

  // Base operations
  getBase(id: number): Promise<Base | undefined>;
  getBaseBySubdomain(subdomain: string): Promise<Base | undefined>;
  getAllBases(): Promise<Base[]>;
  createBase(base: InsertBase): Promise<Base>;
  updateBase(id: number, updates: Partial<Base>): Promise<Base | undefined>;
  deleteBase(id: number): Promise<boolean>;

  // Base User operations
  getBaseUser(id: number): Promise<BaseUser | undefined>;
  getBaseUserByEmail(baseId: number, email: string): Promise<BaseUser | undefined>;
  getBaseUsers(baseId: number): Promise<BaseUser[]>;
  createBaseUser(user: InsertBaseUser): Promise<BaseUser>;
  updateBaseUser(id: number, updates: Partial<BaseUser>): Promise<BaseUser | undefined>;
  deleteBaseUser(id: number): Promise<boolean>;

  // Base Table operations
  getBaseTable(id: number): Promise<BaseTable | undefined>;
  getBaseTables(baseId: number): Promise<BaseTable[]>;
  createBaseTable(table: InsertBaseTable): Promise<BaseTable>;
  updateBaseTable(id: number, updates: Partial<BaseTable>): Promise<BaseTable | undefined>;
  deleteBaseTable(id: number): Promise<boolean>;

  // Table Records operations
  getTableRecords(tableId: number): Promise<any[]>;
  setTableRecords(tableId: number, records: any[]): Promise<void>;
  createTableRecord(tableId: number, record: any): Promise<any>;
  updateTableRecord(tableId: number, recordId: number, updates: any): Promise<any>;
  deleteTableRecord(tableId: number, recordId: number): Promise<boolean>;

  // Field Permission operations
  getFieldPermissions(baseId: number, userId: number, tableId?: number): Promise<FieldPermission[]>;
  setFieldPermission(permission: InsertFieldPermission): Promise<FieldPermission>;
  deleteFieldPermission(id: number): Promise<boolean>;

  // API Token operations
  getApiTokens(baseId: number): Promise<ApiToken[]>;
  createApiToken(token: InsertApiToken): Promise<ApiToken>;
  validateApiToken(token: string): Promise<ApiToken | undefined>;
  deleteApiToken(id: number): Promise<boolean>;

  // Session operations
  createSession(baseId: number, userId: number): Promise<UserSession>;
  getSession(sessionToken: string): Promise<UserSession | undefined>;
  deleteSession(sessionToken: string): Promise<boolean>;

  // Edit Log operations
  createEditLog(log: InsertEditLog): Promise<EditLog>;
  getEditLogs(baseId: number, limit?: number): Promise<EditLog[]>;
  getEditLogsByTable(baseId: number, tableId: number, limit?: number): Promise<EditLog[]>;

  // Magic Link operations
  createMagicLink(link: InsertMagicLink): Promise<MagicLink>;
  getMagicLink(token: string): Promise<MagicLink | undefined>;
  useMagicLink(token: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private superAdmins: Map<number, SuperAdmin>;
  private bases: Map<number, Base>;
  private baseUsers: Map<number, BaseUser>;
  private baseTables: Map<number, BaseTable>;
  private fieldPermissions: Map<number, FieldPermission>;
  private apiTokens: Map<number, ApiToken>;
  private userSessions: Map<string, UserSession>;
  private editLogs: Map<number, EditLog>;
  private magicLinks: Map<string, MagicLink>; // token -> MagicLink
  private tableRecords: Map<number, any[]>; // tableId -> records[]
  
  private currentSuperAdminId: number;
  private currentBaseId: number;
  private currentBaseUserId: number;
  private currentBaseTableId: number;
  private currentFieldPermissionId: number;
  private currentApiTokenId: number;
  private currentSessionId: number;
  private currentEditLogId: number;

  constructor() {
    this.superAdmins = new Map();
    this.bases = new Map();
    this.baseUsers = new Map();
    this.baseTables = new Map();
    this.fieldPermissions = new Map();
    this.apiTokens = new Map();
    this.userSessions = new Map();
    this.editLogs = new Map();
    this.magicLinks = new Map();
    this.tableRecords = new Map();
    
    this.currentSuperAdminId = 1;
    this.currentBaseId = 1;
    this.currentBaseUserId = 1;
    this.currentBaseTableId = 1;
    this.currentFieldPermissionId = 1;
    this.currentApiTokenId = 1;
    this.currentSessionId = 1;
    this.currentEditLogId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create super admin
    const superAdmin: SuperAdmin = {
      id: this.currentSuperAdminId++,
      username: "admin",
      email: "admin@nocobase.com",
      password: "admin123", // In production, this would be hashed
      createdAt: new Date(),
    };
    this.superAdmins.set(superAdmin.id, superAdmin);

    // Create sample bases
    const base1: Base = {
      id: this.currentBaseId++,
      name: "Acme Corp Base",
      subdomain: "acme-corp",
      customDomain: null,
      dbPath: "/data/acme-corp.db",
      status: "active",
      settings: {},
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.bases.set(base1.id, base1);

    const base2: Base = {
      id: this.currentBaseId++,
      name: "TechStart Inc",
      subdomain: "techstart",
      customDomain: null,
      dbPath: "/data/techstart.db",
      status: "active",
      settings: {},
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.bases.set(base2.id, base2);

    // Add SSC6 base for demo with NocoDB integration
    const ssc6Base: Base = {
      id: 4,
      name: "SSC6",
      subdomain: "ssc6",
      customDomain: null,
      dbPath: "/data/ssc6.db",
      status: "active",
      settings: {},
      systemMode: "nocodb",
      deploymentType: "nocodb",
      nocodbBaseId: "prxsww2l3z53hiw",
      nocodbUrl: "https://app.nocodb.com",
      nocodbApiKey: process.env.NOCODB_API_TOKEN || null,
      sitesTableId: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.bases.set(ssc6Base.id, ssc6Base);

    // Create sample base users
    const baseUser1: BaseUser = {
      id: this.currentBaseUserId++,
      baseId: base1.id,
      username: "sarah.wilson",
      email: "sarah@acme-corp.com",
      password: "password123",
      name: "Sarah Wilson",
      role: "admin",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.baseUsers.set(baseUser1.id, baseUser1);

    const baseUser2: BaseUser = {
      id: this.currentBaseUserId++,
      baseId: base1.id,
      username: "john.martinez",
      email: "john@acme-corp.com",
      password: "password123",
      name: "John Martinez",
      role: "editor",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.baseUsers.set(baseUser2.id, baseUser2);

    // Create SSC6 admin user with hashed password
    const ssc6AdminUser: BaseUser = {
      id: this.currentBaseUserId++,
      baseId: ssc6Base.id,
      username: "ssc6@ppmail.com",
      email: "ssc6@ppmail.com",
      password: "bXlwYXNzd29yZDEyMw==", // "mypassword123" hashed
      name: "SSC6 Admin",
      role: "admin",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.baseUsers.set(ssc6AdminUser.id, ssc6AdminUser);

    // No pre-created sample tables or data - will be created via CSV import
  }

  // Super Admin operations
  async getSuperAdmin(id: number): Promise<SuperAdmin | undefined> {
    return this.superAdmins.get(id);
  }

  async getSuperAdminByEmail(email: string): Promise<SuperAdmin | undefined> {
    return Array.from(this.superAdmins.values()).find(admin => admin.email === email);
  }

  async createSuperAdmin(admin: InsertSuperAdmin): Promise<SuperAdmin> {
    const newAdmin: SuperAdmin = {
      ...admin,
      id: this.currentSuperAdminId++,
      createdAt: new Date(),
    };
    this.superAdmins.set(newAdmin.id, newAdmin);
    return newAdmin;
  }

  // Base operations
  async getBase(id: number): Promise<Base | undefined> {
    return this.bases.get(id);
  }

  async getBaseBySubdomain(subdomain: string): Promise<Base | undefined> {
    return Array.from(this.bases.values()).find(base => base.subdomain === subdomain);
  }

  async getAllBases(): Promise<Base[]> {
    return Array.from(this.bases.values());
  }

  async createBase(base: InsertBase): Promise<Base> {
    const newBase: Base = {
      ...base,
      id: this.currentBaseId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.bases.set(newBase.id, newBase);
    return newBase;
  }

  async updateBase(id: number, updates: Partial<Base>): Promise<Base | undefined> {
    const base = this.bases.get(id);
    if (!base) return undefined;
    
    const updatedBase = { ...base, ...updates, updatedAt: new Date() };
    this.bases.set(id, updatedBase);
    return updatedBase;
  }

  async deleteBase(id: number): Promise<boolean> {
    return this.bases.delete(id);
  }

  // Base User operations
  async getBaseUser(id: number): Promise<BaseUser | undefined> {
    return this.baseUsers.get(id);
  }

  async getBaseUserByEmail(baseId: number, email: string): Promise<BaseUser | undefined> {
    return Array.from(this.baseUsers.values()).find(
      user => user.baseId === baseId && user.email === email
    );
  }

  async getBaseUsers(baseId: number): Promise<BaseUser[]> {
    return Array.from(this.baseUsers.values()).filter(user => user.baseId === baseId);
  }

  async createBaseUser(user: InsertBaseUser): Promise<BaseUser> {
    const newUser: BaseUser = {
      ...user,
      id: this.currentBaseUserId++,
      isActive: user.isActive ?? true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.baseUsers.set(newUser.id, newUser);
    return newUser;
  }

  async updateBaseUser(id: number, updates: Partial<BaseUser>): Promise<BaseUser | undefined> {
    const user = this.baseUsers.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates, updatedAt: new Date() };
    this.baseUsers.set(id, updatedUser);
    return updatedUser;
  }

  async deleteBaseUser(id: number): Promise<boolean> {
    return this.baseUsers.delete(id);
  }

  // Base Table operations
  async getBaseTable(id: number): Promise<BaseTable | undefined> {
    return this.baseTables.get(id);
  }

  async getBaseTables(baseId: number): Promise<BaseTable[]> {
    return Array.from(this.baseTables.values()).filter(table => table.baseId === baseId);
  }

  async createBaseTable(table: InsertBaseTable): Promise<BaseTable> {
    const newTable: BaseTable = {
      ...table,
      id: this.currentBaseTableId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.baseTables.set(newTable.id, newTable);
    return newTable;
  }

  async updateBaseTable(id: number, updates: Partial<BaseTable>): Promise<BaseTable | undefined> {
    const table = this.baseTables.get(id);
    if (!table) return undefined;
    
    const updatedTable = { ...table, ...updates, updatedAt: new Date() };
    this.baseTables.set(id, updatedTable);
    return updatedTable;
  }

  async deleteBaseTable(id: number): Promise<boolean> {
    return this.baseTables.delete(id);
  }

  // Field Permission operations
  async getFieldPermissions(baseId: number, userId: number, tableId?: number): Promise<FieldPermission[]> {
    const allPermissions = Array.from(this.fieldPermissions.values());
    console.log('=== GET PERMISSIONS DEBUG ===');
    console.log('Looking for:', { baseId, userId, tableId });
    console.log('All permissions:', allPermissions);
    
    const filtered = allPermissions.filter(
      permission => 
        permission.baseId === baseId && 
        permission.userId === userId &&
        (tableId === undefined || permission.tableId === tableId)
    );
    
    console.log('Filtered permissions:', filtered);
    return filtered;
  }

  async setFieldPermission(permission: InsertFieldPermission): Promise<FieldPermission> {
    console.log('=== SET PERMISSION DEBUG ===');
    console.log('Setting permission:', permission);
    
    // Check if permission already exists
    const existing = Array.from(this.fieldPermissions.values()).find(
      p => p.baseId === permission.baseId && 
          p.userId === permission.userId && 
          p.tableId === permission.tableId && 
          p.fieldName === permission.fieldName
    );

    console.log('Existing permission found:', existing);

    if (existing) {
      // Update existing permission
      const updated = { ...existing, permission: permission.permission, updatedAt: new Date() };
      this.fieldPermissions.set(existing.id, updated);
      console.log('Updated permission:', updated);
      return updated;
    } else {
      // Create new permission
      const newPermission: FieldPermission = {
        ...permission,
        id: this.currentFieldPermissionId++,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.fieldPermissions.set(newPermission.id, newPermission);
      console.log('Created new permission:', newPermission);
      console.log('Total permissions now:', this.fieldPermissions.size);
      return newPermission;
    }
  }

  async deleteFieldPermission(id: number): Promise<boolean> {
    return this.fieldPermissions.delete(id);
  }

  // API Token operations
  async getApiTokens(baseId: number): Promise<ApiToken[]> {
    return Array.from(this.apiTokens.values()).filter(token => token.baseId === baseId);
  }

  async createApiToken(token: InsertApiToken): Promise<ApiToken> {
    const newToken: ApiToken = {
      ...token,
      id: this.currentApiTokenId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.apiTokens.set(newToken.id, newToken);
    return newToken;
  }

  async validateApiToken(token: string): Promise<ApiToken | undefined> {
    return Array.from(this.apiTokens.values()).find(
      t => t.token === token && t.isActive && (t.expiresAt === null || t.expiresAt > new Date())
    );
  }

  async deleteApiToken(id: number): Promise<boolean> {
    return this.apiTokens.delete(id);
  }

  // Session operations
  async createSession(baseId: number, userId: number): Promise<UserSession> {
    const sessionToken = Math.random().toString(36).substring(2) + Date.now().toString(36);
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24); // 24 hour session

    const session: UserSession = {
      id: this.currentSessionId++,
      baseId,
      userId,
      sessionToken,
      expiresAt,
      createdAt: new Date(),
    };

    this.userSessions.set(sessionToken, session);
    return session;
  }

  async getSession(sessionToken: string): Promise<UserSession | undefined> {
    const session = this.userSessions.get(sessionToken);
    if (session && session.expiresAt > new Date()) {
      return session;
    }
    if (session) {
      this.userSessions.delete(sessionToken);
    }
    return undefined;
  }

  async deleteSession(sessionToken: string): Promise<boolean> {
    return this.userSessions.delete(sessionToken);
  }

  // Magic Link operations
  async createMagicLink(link: InsertMagicLink): Promise<MagicLink> {
    const newLink: MagicLink = {
      id: this.currentEditLogId++, // reuse counter for now
      ...link,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.magicLinks.set(link.token, newLink);
    return newLink;
  }

  async getMagicLink(token: string): Promise<MagicLink | undefined> {
    return this.magicLinks.get(token);
  }

  async useMagicLink(token: string): Promise<boolean> {
    const link = this.magicLinks.get(token);
    if (link && link.expiresAt > new Date()) {
      this.magicLinks.delete(token);
      return true;
    }
    return false;
  }

  // Edit Log operations
  async createEditLog(log: InsertEditLog): Promise<EditLog> {
    const newLog: EditLog = {
      id: this.currentEditLogId++,
      ...log,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.editLogs.set(newLog.id, newLog);
    return newLog;
  }

  async getEditLogs(baseId: number, limit?: number): Promise<EditLog[]> {
    const logs = Array.from(this.editLogs.values())
      .filter(log => log.baseId === baseId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return limit ? logs.slice(0, limit) : logs;
  }

  async getEditLogsByTable(baseId: number, tableId: number, limit?: number): Promise<EditLog[]> {
    const logs = Array.from(this.editLogs.values())
      .filter(log => log.baseId === baseId && log.tableId === tableId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    return limit ? logs.slice(0, limit) : logs;
  }

  // Table Records operations
  async getTableRecords(tableId: number): Promise<any[]> {
    return this.tableRecords.get(tableId) || [];
  }

  async setTableRecords(tableId: number, records: any[]): Promise<void> {
    this.tableRecords.set(tableId, records);
  }

  async createTableRecord(tableId: number, record: any): Promise<any> {
    const currentRecords = this.tableRecords.get(tableId) || [];
    const newId = Math.max(0, ...currentRecords.map(r => r.id || 0)) + 1;
    const newRecord = { ...record, id: newId };
    currentRecords.push(newRecord);
    this.tableRecords.set(tableId, currentRecords);
    return newRecord;
  }

  async updateTableRecord(tableId: number, recordId: number, updates: any): Promise<any> {
    const currentRecords = this.tableRecords.get(tableId) || [];
    const index = currentRecords.findIndex(r => r.id === recordId);
    if (index === -1) return undefined;
    
    currentRecords[index] = { ...currentRecords[index], ...updates };
    this.tableRecords.set(tableId, currentRecords);
    return currentRecords[index];
  }

  async deleteTableRecord(tableId: number, recordId: number): Promise<boolean> {
    const currentRecords = this.tableRecords.get(tableId) || [];
    const index = currentRecords.findIndex(r => r.id === recordId);
    if (index === -1) return false;
    
    currentRecords.splice(index, 1);
    this.tableRecords.set(tableId, currentRecords);
    return true;
  }
}

// Database-backed storage implementation
export class DatabaseStorage implements IStorage {
  // Super Admin operations
  async getSuperAdmin(id: number): Promise<SuperAdmin | undefined> {
    const [admin] = await db.select().from(superAdmins).where(eq(superAdmins.id, id));
    return admin || undefined;
  }

  async getSuperAdminByEmail(email: string): Promise<SuperAdmin | undefined> {
    const [admin] = await db.select().from(superAdmins).where(eq(superAdmins.email, email));
    return admin || undefined;
  }

  async createSuperAdmin(admin: InsertSuperAdmin): Promise<SuperAdmin> {
    const [newAdmin] = await db.insert(superAdmins).values(admin).returning();
    return newAdmin;
  }

  // Base operations
  async getBase(id: number): Promise<Base | undefined> {
    const [base] = await db.select().from(bases).where(eq(bases.id, id));
    return base || undefined;
  }

  async getBaseBySubdomain(subdomain: string): Promise<Base | undefined> {
    const [base] = await db.select().from(bases).where(eq(bases.subdomain, subdomain));
    return base || undefined;
  }

  async getAllBases(): Promise<Base[]> {
    return await db.select().from(bases);
  }

  async createBase(base: InsertBase): Promise<Base> {
    const [newBase] = await db.insert(bases).values(base).returning();
    return newBase;
  }

  async updateBase(id: number, updates: Partial<Base>): Promise<Base | undefined> {
    const [updatedBase] = await db.update(bases).set(updates).where(eq(bases.id, id)).returning();
    return updatedBase || undefined;
  }

  async deleteBase(id: number): Promise<boolean> {
    const result = await db.delete(bases).where(eq(bases.id, id));
    return result.rowCount > 0;
  }

  // Base User operations
  async getBaseUser(id: number): Promise<BaseUser | undefined> {
    const [user] = await db.select().from(baseUsers).where(eq(baseUsers.id, id));
    return user || undefined;
  }

  async getBaseUserByEmail(baseId: number, email: string): Promise<BaseUser | undefined> {
    const [user] = await db.select().from(baseUsers)
      .where(and(eq(baseUsers.baseId, baseId), eq(baseUsers.email, email)));
    return user || undefined;
  }

  async getBaseUsers(baseId: number): Promise<BaseUser[]> {
    return await db.select().from(baseUsers).where(eq(baseUsers.baseId, baseId));
  }

  async createBaseUser(user: InsertBaseUser): Promise<BaseUser> {
    const [newUser] = await db.insert(baseUsers).values(user).returning();
    return newUser;
  }

  async updateBaseUser(id: number, updates: Partial<BaseUser>): Promise<BaseUser | undefined> {
    const [updatedUser] = await db.update(baseUsers).set(updates).where(eq(baseUsers.id, id)).returning();
    return updatedUser || undefined;
  }

  async deleteBaseUser(id: number): Promise<boolean> {
    const result = await db.delete(baseUsers).where(eq(baseUsers.id, id));
    return result.rowCount > 0;
  }

  // Base Table operations
  async getBaseTable(id: number): Promise<BaseTable | undefined> {
    const [table] = await db.select().from(baseTables).where(eq(baseTables.id, id));
    return table || undefined;
  }

  async getBaseTables(baseId: number): Promise<BaseTable[]> {
    return await db.select().from(baseTables).where(eq(baseTables.baseId, baseId));
  }

  async createBaseTable(table: InsertBaseTable): Promise<BaseTable> {
    const [newTable] = await db.insert(baseTables).values(table).returning();
    return newTable;
  }

  async updateBaseTable(id: number, updates: Partial<BaseTable>): Promise<BaseTable | undefined> {
    const [updatedTable] = await db.update(baseTables).set(updates).where(eq(baseTables.id, id)).returning();
    return updatedTable || undefined;
  }

  async deleteBaseTable(id: number): Promise<boolean> {
    const result = await db.delete(baseTables).where(eq(baseTables.id, id));
    return result.rowCount > 0;
  }

  // Field Permission operations
  async getFieldPermissions(baseId: number, userId: number, tableId?: number): Promise<FieldPermission[]> {
    let query = db.select().from(fieldPermissions)
      .where(and(eq(fieldPermissions.baseId, baseId), eq(fieldPermissions.userId, userId)));
    
    if (tableId !== undefined) {
      query = query.where(eq(fieldPermissions.tableId, tableId));
    }
    
    return await query;
  }

  async setFieldPermission(permission: InsertFieldPermission): Promise<FieldPermission> {
    const [newPermission] = await db.insert(fieldPermissions).values(permission).returning();
    return newPermission;
  }

  async deleteFieldPermission(id: number): Promise<boolean> {
    const result = await db.delete(fieldPermissions).where(eq(fieldPermissions.id, id));
    return result.rowCount > 0;
  }

  // API Token operations
  async getApiTokens(baseId: number): Promise<ApiToken[]> {
    return await db.select().from(apiTokens).where(eq(apiTokens.baseId, baseId));
  }

  async createApiToken(token: InsertApiToken): Promise<ApiToken> {
    const [newToken] = await db.insert(apiTokens).values(token).returning();
    return newToken;
  }

  async validateApiToken(token: string): Promise<ApiToken | undefined> {
    const [apiToken] = await db.select().from(apiTokens).where(eq(apiTokens.token, token));
    return apiToken || undefined;
  }

  async deleteApiToken(id: number): Promise<boolean> {
    const result = await db.delete(apiTokens).where(eq(apiTokens.id, id));
    return result.rowCount > 0;
  }

  // Session operations
  async createSession(baseId: number, userId: number): Promise<UserSession> {
    const sessionToken = nanoid(32);
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    const [session] = await db.insert(userSessions).values({
      sessionToken,
      baseId,
      userId,
      expiresAt
    }).returning();

    return session;
  }

  async getSession(sessionToken: string): Promise<UserSession | undefined> {
    const [session] = await db.select().from(userSessions)
      .where(and(
        eq(userSessions.sessionToken, sessionToken),
        gt(userSessions.expiresAt, new Date())
      ));
    return session || undefined;
  }

  async deleteSession(sessionToken: string): Promise<boolean> {
    const result = await db.delete(userSessions).where(eq(userSessions.sessionToken, sessionToken));
    return result.rowCount > 0;
  }

  // Edit Log operations
  async createEditLog(log: InsertEditLog): Promise<EditLog> {
    const [newLog] = await db.insert(editLogs).values(log).returning();
    return newLog;
  }

  async getEditLogs(baseId: number, limit?: number): Promise<EditLog[]> {
    let query = db.select().from(editLogs)
      .where(eq(editLogs.baseId, baseId))
      .orderBy(desc(editLogs.createdAt));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return await query;
  }

  async getEditLogsByTable(baseId: number, tableId: number, limit?: number): Promise<EditLog[]> {
    let query = db.select().from(editLogs)
      .where(and(eq(editLogs.baseId, baseId), eq(editLogs.tableId, tableId)))
      .orderBy(desc(editLogs.createdAt));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return await query;
  }

  // Magic Link operations
  async createMagicLink(link: InsertMagicLink): Promise<MagicLink> {
    const [newLink] = await db.insert(magicLinks).values(link).returning();
    return newLink;
  }

  async getMagicLink(token: string): Promise<MagicLink | undefined> {
    const [link] = await db.select().from(magicLinks)
      .where(and(
        eq(magicLinks.token, token),
        gt(magicLinks.expiresAt, new Date()),
        eq(magicLinks.isUsed, false)
      ));
    return link || undefined;
  }

  async useMagicLink(token: string): Promise<boolean> {
    const result = await db.update(magicLinks)
      .set({ isUsed: true, usedAt: new Date() })
      .where(eq(magicLinks.token, token));
    return result.rowCount > 0;
  }

  // Table Records operations (simplified for file-based storage)
  async getTableRecords(tableId: number): Promise<any[]> {
    // For production, records would be stored in database tables or files
    // This is a placeholder implementation
    return [];
  }

  async setTableRecords(tableId: number, records: any[]): Promise<void> {
    // Implementation would depend on storage strategy
  }

  async createTableRecord(tableId: number, record: any): Promise<any> {
    // Implementation would create new record
    return { id: Date.now(), ...record };
  }

  async updateTableRecord(tableId: number, recordId: number, updates: any): Promise<any> {
    // Implementation would update existing record
    return { id: recordId, ...updates };
  }

  async deleteTableRecord(tableId: number, recordId: number): Promise<boolean> {
    // Implementation would delete record
    return true;
  }
}

// Use DatabaseStorage for production, MemStorage for development
export const storage = process.env.NODE_ENV === 'production' 
  ? new DatabaseStorage() 
  : new MemStorage();
